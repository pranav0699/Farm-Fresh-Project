package com.farmfresh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmFreshApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmFreshApplication.class, args);
	}

}
